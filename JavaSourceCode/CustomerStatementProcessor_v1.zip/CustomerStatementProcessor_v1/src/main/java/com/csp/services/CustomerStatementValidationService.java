package com.csp.services;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.csp.custom.annotation.model.ValidationResult;
import com.csp.custom.annotation.validator.AbstractValidator;
import com.csp.custom.annotation.validator.UniqueValidator;
import com.csp.custom.annotation.validator.ValidEndBalanceValidator;
import com.csp.custom.exception.CoreException;
import com.csp.custom.exception.OperationFailedException;
import com.csp.custom.exception.ResourceNotFoundException;
import com.csp.dto.CustomerStatement;
import com.csp.dto.GenericResponse;
import com.csp.util.CSPUtils;

@Service
public class CustomerStatementValidationService implements ICustomerStatementValidationService{

	final static Logger logger = Logger.getLogger(CustomerStatementValidationService.class);

	List < AbstractValidator > availableValidators;

	
	/*
	 * This will initialize the required validators 
	 */
	@PostConstruct
	private void setupValidators() {
		availableValidators = new LinkedList < AbstractValidator > ();
		availableValidators.add(new UniqueValidator());
		availableValidators.add(new ValidEndBalanceValidator());
	}

	/*
	 * Method is used to validate the attributes based on the configured annotations.
	 * Once the validation done the result will be collected as List<ValidationResult>. 
	 */
	private < T > List < Object > applyValidators(T t)throws CoreException {
		logger.info("Started applying validation on field level for the configured items");
		List < Object > results = new LinkedList < Object > ();
		try {
			for (AbstractValidator validator: availableValidators) {
				List < ValidationResult > result = validator.evaluateValidations(t);
				results.addAll(result);
			}
		} catch(IllegalArgumentException  | IllegalAccessException e){
			throw new OperationFailedException("CSP","500","Illegal argument or Illegal Access");
		}catch(Exception e){
			throw new CoreException("CSP","501","Unexcepted error occured while applying validation.");
		}
		logger.info("Validation on field level for the configured items is completed");
		return results;
	}

	/*
	 * Method to read Customer statement file using CSVParser from Apache Commons CSV
	 */
	public GenericResponse processStmnt(String customerStatementPath) {
		logger.info("Started Validating Customer Statement");
		GenericResponse resp = new GenericResponse();
		List < Object > validationResults = new LinkedList < Object > ();
		try {
			setupValidators();
			for (CustomerStatement custStmnt : readStmnt(customerStatementPath))
				validationResults.addAll(applyValidators(custStmnt));
			resp.setResult(validationResults);
			resp.setMsgCode(200);
			logger.info("Validating Customer Statement is Completed");
		}catch(ResourceNotFoundException e){
			logger.error(e.getMessage());
		}catch(OperationFailedException e){
			logger.error(e.getMessage());
		}catch (CoreException e) {
			logger.error(e.getMessage());
		}
		return resp;
	}

	/**
	 * This method is used to parse the given customer statement( csv file ) 
	 * @return - returns List<CustomerStatement> - 
	 * @throws CoreException -  raised when an runtime exception occurs in the system
	 */
	public List<CustomerStatement> readStmnt(String customerStatementPath) throws CoreException {
		logger.info("Started Reading Customer Statement File ");
		List<CustomerStatement> customerDetails = new ArrayList<>();
		try(CSVParser parser = new CSVParser(new FileReader(customerStatementPath), CSVFormat.DEFAULT.withHeader())){
			for (CSVRecord record : parser) {
				CustomerStatement custStmnt = new CustomerStatement();
				if(!CSPUtils.isNullOrEmptyOrDefault(record.get("Reference")))
					custStmnt.setTransactionRefNumber(Long.valueOf(record.get("Reference")));
				if(!CSPUtils.isNullOrEmptyOrDefault(record.get("AccountNumber")))
					custStmnt.setAccntNumber(record.get("AccountNumber"));
				if(!CSPUtils.isNullOrEmptyOrDefault(record.get("Description")))
					custStmnt.setDesc(record.get("Description"));
				if(!CSPUtils.isNullOrEmptyOrDefault(record.get("Start Balance")))
					custStmnt.setStartBalance(record.get("Start Balance"));
				if(!CSPUtils.isNullOrEmptyOrDefault(record.get("Mutation")))
					custStmnt.setMutation(record.get("Mutation"));
				if(!CSPUtils.isNullOrEmptyOrDefault(record.get("End Balance")))
					custStmnt.setEndBalance(record.get("End Balance"));
				customerDetails.add(custStmnt);
			}
			if(customerDetails.size() ==0)
				throw new OperationFailedException("CSP","500","Input File appears empty!");
			logger.info("Customer Statement File has "+customerDetails.size()+" records");
			logger.info("Reading Customer Statement File is Completed");
		}catch(FileNotFoundException e){
			throw new ResourceNotFoundException("CSP","404","Customer Statement File Not present in the location or not accessible");
		}catch(OperationFailedException e){
			throw new OperationFailedException(e.getMessage());
		}catch(Exception e){
			throw new CoreException("CSP","501","Unexcepted error occured while processing Statement.");
		}
		return customerDetails;
	}
}

