package com.csp.custom.exception;

public class OperationFailedException extends CoreException {

	public OperationFailedException() {
		super();
	}

	public OperationFailedException(String message) {
		super(message);
	}


	public OperationFailedException(String appName, String code, String message, Throwable cause) {
		super(appName, code, message, cause);
	}

	public OperationFailedException(String appName, String code, String message) {
		super(appName, code, message);
	}

	public OperationFailedException(Throwable cause) {
		super(cause);
	}

}
