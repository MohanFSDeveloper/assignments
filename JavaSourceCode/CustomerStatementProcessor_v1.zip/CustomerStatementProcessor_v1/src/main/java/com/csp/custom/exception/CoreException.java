package com.csp.custom.exception;
public class CoreException extends Exception
{
	private boolean isLogged = false;
	private String code;
	private String appName;
	
	public CoreException() {
		super();
    }

	protected CoreException(String appName, String code,String message,Throwable rootCause)
	{
		super(message,rootCause);
		this.code = code;
		this.appName = appName;
	}

	public CoreException(String appName, String code,String message)
	{
		super(message);
		this.code = code;
		this.appName = appName;
	}

	public CoreException(String message) {
		super(message);
	}

	public CoreException(String message, Throwable cause) {
		super(message, cause);
	}

	public CoreException(Throwable cause) {
		super(cause.getMessage(), cause);
	}

	public String getCode()	{
		return code;
	}

	public String getAppName() {
		return appName;
	}
	
	public final boolean isLogged() {
		return isLogged;
	}

	public final void setLogged(boolean aisLogged) {
		this.isLogged = aisLogged;
	}
	
	@Override
	public String getMessage()
	{
		StringBuffer sb = new StringBuffer();

		sb.append("[").append(getAppName()).append("] ");
		sb.append("[").append(getCode()).append("] ");
		sb.append(super.getMessage());

		return sb.toString();
	}
}
