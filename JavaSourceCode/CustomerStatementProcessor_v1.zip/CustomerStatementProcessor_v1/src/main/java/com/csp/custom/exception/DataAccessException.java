package com.csp.custom.exception;

public class DataAccessException extends CoreException {

	public DataAccessException() {
		super();
	}
	
	public DataAccessException( String message) {
		super(message);
	}

	public DataAccessException(String appName, String code, String message, Throwable cause) {
		super(appName, code, message, cause);
	}

	public DataAccessException(String appName, String code, String message) {
		super(appName, code, message);
	}

	public DataAccessException(Throwable cause) {
		super(cause);
	}
}
