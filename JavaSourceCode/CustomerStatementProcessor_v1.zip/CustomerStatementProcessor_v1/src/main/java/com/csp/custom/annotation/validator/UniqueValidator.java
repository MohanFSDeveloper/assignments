package com.csp.custom.annotation.validator;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.csp.custom.annotation.DefaultRegister;
import com.csp.custom.annotation.IsUnique;
import com.csp.custom.annotation.model.ValidationResult;
import com.csp.custom.annotation.model.ValidatorConstants;

public class UniqueValidator extends AbstractValidator {

	@Override
	protected <T> void initialize(T t) {
	}
	private List<Object> referenceNumbers = null;
	
	final static Logger logger = Logger.getLogger(UniqueValidator.class);
	
	public UniqueValidator(){
		referenceNumbers = new ArrayList<Object>();
	}
	/**
	 * Find out unique fields based on annotation (@IsUnique) from passed object and applies the validation
	 */
	@Override
	protected List<ValidationResult> validateAnnotationForField(Object object) throws IllegalArgumentException, IllegalAccessException {
		logger.info("Started validating unique fields");
		List<ValidationResult> invalidObjects = new ArrayList<ValidationResult>(0);
		Class<?> clazz = object.getClass();
		for(Field f: clazz.getDeclaredFields()) {
			if(f.isAnnotationPresent(IsUnique.class)) {
				f.setAccessible(true);
				IsUnique annotation = f.getAnnotation(IsUnique.class);
				DefaultRegister defaultAnnotation = f.getAnnotation(DefaultRegister.class);
				Object id = f.get(object);
				logger.info("Going to validate whether the reference number is unique or not"+id);
				if(!meetsValidation(id, annotation)) { 
					invalidObjects.add(new ValidationResult(id,getBusinessName(defaultAnnotation), id,annotation.message()));
				}
				f.setAccessible(false);
			}
		}
		logger.info("Validating unique fields is completed");
		return invalidObjects;
	}

	/**
	 * Validate whether the reference number is duplicate or not and returns true if reference number
	 * exist else return false.
	 */
	@Override
	protected <V, A extends Annotation> boolean meetsValidation(V value, A a) throws IllegalArgumentException, IllegalAccessException  {
		logger.info("Checking the reference is exist or not");
		if(referenceNumbers.size() == 0 && value != null){
			referenceNumbers.add(value);
			return true;
		}
		if(referenceNumbers.contains(value)){
			return false;
		}
		referenceNumbers.add(value);
		return true;
	}

	/*
	 * Returns validator name
	 */
	@Override
	protected String getValidatorName() {
		return ValidatorConstants.UNIQUE_VALIDATOR;
	}


}
