package com.csp.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.csp.dto.GenericResponse;
import com.csp.services.ICustomerStatementValidationService;

/**
 * 
 * @author MohanRaj
 * Handles request triggered from UI
 */
@RestController
public class CustomerStatementController 
{
	final static Logger logger = Logger.getLogger(CustomerStatementController.class);

	@Autowired
	private ICustomerStatementValidationService customerStatementValidationService;
	
	
	/**
	 * Inject the customer statement path from property file
	 */
	@Value("${application.customerstatement.path}")
	private String customerStatementPath;

	/**
	 * 
	 * @return GenericResponse - which contains detailed information about the response. 
	 * Such as result ,response code,status,etc..
	 */
	@RequestMapping("/processStmnt/")
	public  GenericResponse processStmnt(){
		logger.info("Customer Statement Processing Started");
		return customerStatementValidationService.processStmnt(customerStatementPath);
	}

}
