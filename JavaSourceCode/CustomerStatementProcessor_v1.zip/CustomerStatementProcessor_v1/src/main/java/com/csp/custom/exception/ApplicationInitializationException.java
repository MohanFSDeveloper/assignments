package com.csp.custom.exception;

public class ApplicationInitializationException extends CoreException {

	public ApplicationInitializationException() {
		super();
	}

	public ApplicationInitializationException(String appName, String code, String message, Throwable cause) {
		super(appName, code, message, cause);
	}

	public ApplicationInitializationException(String appName, String code, String message) {
		super(appName, code, message);
	}

	public ApplicationInitializationException(Throwable cause) {
		super(cause);
	}

}
