package com.csp.custom.annotation.model;

public interface ValidatorConstants {

	public static final String DEFAULT_VALUE_INTEGER = "-1";
	public static final String UNIQUE_VALIDATOR = "UniqueValidator";
	public static final String VALID_END_BALANCE_VALIDATOR = "ValidEndBalanceValidator";
}
