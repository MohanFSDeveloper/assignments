package com.csp.services;

import com.csp.dto.GenericResponse;



public interface ICustomerStatementValidationService {
	
	GenericResponse processStmnt(String customerStatementPath);

}
