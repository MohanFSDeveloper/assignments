package com.csp.custom.exception;

public class ResourceNotFoundException extends CoreException {

	public ResourceNotFoundException() {
		super();
	}

	public ResourceNotFoundException(String message) {
		super(message);
	}


	public ResourceNotFoundException(String appName, String code, String message, Throwable cause) {
		super(appName, code, message, cause);
	}

	public ResourceNotFoundException(String appName, String code, String message) {
		super(appName, code, message);
	}

	public ResourceNotFoundException(Throwable cause) {
		super(cause);
	}

}
