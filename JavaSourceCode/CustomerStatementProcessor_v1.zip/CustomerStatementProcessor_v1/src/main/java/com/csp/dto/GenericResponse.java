package com.csp.dto;


public class GenericResponse {

	private boolean status;
	private int msgCode;
	private Object result;
	private String msgDesc;
	
	public GenericResponse(int msgCode, boolean status) {
		this.status = status;
		this.msgCode = msgCode;
	}

	public GenericResponse() {
		super();
		this.status = false;
		this.msgCode = 500;
		this.msgDesc = "Unable to process";
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public int getMsgCode() {
		return msgCode;
	}
	public void setMsgCode(int msgCode) {
		this.msgCode = msgCode;
	}
	public String getMsgDesc() {
		return msgDesc;
	}
	public void setMsgDesc(String msgDesc) {
		this.msgDesc = msgDesc;
	}
	@Override
	public String toString() {
		return "GenericResponse [status=" + status + ", msgCode=" + msgCode + ", msgDesc=" + msgDesc + "]";
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}

	
}