/**
 * This file has csp angualr app initilization code.
 */

var csp = angular.module("csp", ['ui.grid','ui.grid.pagination','ui.grid.moveColumns','ui.grid.exporter','ui.grid.selection','ui.grid.resizeColumns','ui.grid.autoResize','ui.grid.expandable',]);